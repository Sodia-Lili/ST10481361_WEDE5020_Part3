// JavaScript for Carousel Functionality
window.onload = function() {
  // New Arrivals Carousel
  const newImages = document.getElementById('carousel-new-images');
  document.getElementById('carousel-new-left').onclick = function() {
    newImages.insertBefore(newImages.lastElementChild, newImages.firstElementChild);
  };
  document.getElementById('carousel-new-right').onclick = function() {
    newImages.appendChild(newImages.firstElementChild);
  };

  // Best Sellers Carousel
  const bestImages = document.getElementById('carousel-best-images');
  document.getElementById('carousel-best-left').onclick = function() {
    bestImages.insertBefore(bestImages.lastElementChild, bestImages.firstElementChild);
  };
  document.getElementById('carousel-best-right').onclick = function() {
    bestImages.appendChild(bestImages.firstElementChild);
  };

  // Our Products Carousel
  const productsImages = document.getElementById('carousel-products-images');
  document.getElementById('carousel-products-left').onclick = function() {
    productsImages.insertBefore(productsImages.lastElementChild, productsImages.firstElementChild);
  };
  document.getElementById('carousel-products-right').onclick = function() {
    productsImages.appendChild(productsImages.firstElementChild);
  };

  // Featured Sellers Carousel
  const featuredImages = document.getElementById('carousel-featured-images');
  document.getElementById('carousel-featured-left').onclick = function() {
    featuredImages.insertBefore(featuredImages.lastElementChild, featuredImages.firstElementChild);
  };
  document.getElementById('carousel-featured-right').onclick = function() {
    featuredImages.appendChild(featuredImages.firstElementChild);
  };
};

// JavaScript for Hamburger Menu and Carousel Functionality
const hamburger = document.querySelector(".hamburger");
const navLinks = document.querySelector(".nav-links");

hamburger.addEventListener("click", () => {
  navLinks.style.display = navLinks.style.display === "flex" ? "none" : "flex";
});

// Additional JavaScript Functionality for Services and Enquiry Pages
document.addEventListener('DOMContentLoaded', function () {

  /* ---------- LIGHTBOX ---------- */
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-image'); // Ensure this ID matches your HTML
  const lightboxCaption = document.getElementById('lightbox-caption');
  const lightboxClose = document.getElementById('lightbox-close');

  // Open lightbox on image click
  document.addEventListener('click', function (e) {
    const target = e.target;
    if (target.matches('[id$="-images"] img, .product-item img')) {
      e.preventDefault();
      lightboxImg.src = target.src; // Set the lightbox image source
      lightboxImg.alt = target.alt; // Set the lightbox image alt text
      lightboxCaption.textContent = target.alt; // Set the caption
      lightbox.classList.remove('hidden'); // Show the lightbox
      document.body.style.overflow = 'hidden'; // Prevent background scrolling
    }
  });
//(W3Schools. n.d.)
  function closeLightbox() {
    lightbox.classList.add('hidden'); // Hide the lightbox
    lightboxImg.src = ''; // Clear the image source
    lightboxCaption.textContent = ''; // Clear the caption
    document.body.style.overflow = ''; // Restore scrolling
  }

  if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLightbox();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !lightbox.classList.contains('hidden')) closeLightbox();
  });

  /* ---------- LIGHTBOX: supports .gallery, carousels ([id$="-images"]) and .product-item ---------- */
  (function () {
    const lightbox = document.getElementById('lightbox'); 
    if (!lightbox) return;

    const lbImage = document.getElementById('lightbox-image'); // Ensure this ID matches your HTML
    const lbCaption = document.getElementById('lightbox-caption'); // Ensure this ID matches your HTML
    const btnClose = lightbox.querySelector('.lightbox-close');
    const btnPrev = lightbox.querySelector('.lightbox-prev');
    const btnNext = lightbox.querySelector('.lightbox-next');

    function getGalleryImages() {
      return Array.from(document.querySelectorAll('.gallery img, [id$="-images"] img, .product-item img'));
    }

    function openLightbox(imgEl) {
      if (!imgEl || !lbImage) return; // safety check
      const src = imgEl.dataset.full || imgEl.currentSrc || imgEl.src;
      const caption = imgEl.dataset.caption || imgEl.alt || imgEl.getAttribute('data-name') || '';
      lbImage.src = src;
      lbImage.alt = caption;
      if (lbCaption) lbCaption.textContent = caption; // set caption text
      lightbox.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';

      const imgs = getGalleryImages();// get all images in galleries
      lightbox.dataset.current = String(imgs.indexOf(imgEl));
      if (btnClose) btnClose.focus();
    }
    
    function closeLightbox() { // close lightbox function
      lightbox.setAttribute('aria-hidden', 'true');
      if (lbImage) { lbImage.src = ''; lbImage.alt = ''; }
      if (lbCaption) lbCaption.textContent = '';
      document.body.style.overflow = '';
      delete lightbox.dataset.current;
    }

    function showOffset(offset) { // show next/prev image
      const imgs = getGalleryImages();
      if (!imgs.length) return;
      let idx = parseInt(lightbox.dataset.current || '0', 10);
      idx = (idx + offset + imgs.length) % imgs.length;
      const el = imgs[idx];
      if (el) openLightbox(el);
    }
//(W3Schools. n.d.)
    document.addEventListener('click', function (e) {
      const t = e.target;
      if (!t || !t.matches) return;
      if (t.matches('.gallery img') || t.matches('[id$="-images"] img') || t.matches('.product-item img')) {
        e.preventDefault();
        openLightbox(t);
      }
    });

    if (btnClose) btnClose.addEventListener('click', closeLightbox);
    if (btnPrev) btnPrev.addEventListener('click', function () { showOffset(-1); });
    if (btnNext) btnNext.addEventListener('click', function () { showOffset(1); });

    document.addEventListener('keydown', function (e) {
      if (lightbox.getAttribute('aria-hidden') === 'false') {
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') showOffset(-1);
        if (e.key === 'ArrowRight') showOffset(1);
      }
    });

    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox) closeLightbox();
    });
  })();
//(W3Schools. n.d.)
  /* ---------- CONTACT FORM VALIDATION & SUBMIT (prevent normal submit) ---------- */
  const contactForm = document.getElementById('contactForm'); // Ensure this ID matches your HTML
  const contactResponse = document.getElementById('contact-response');

  if (contactForm) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault(); // always prevent normal submit

      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const message = document.getElementById('message').value.trim();

      // Basic validation
      if (!name || !email || !message) {
        contactResponse.innerHTML = '<p class="error">Please fill in all fields.</p>';
        return;
      }

      // Email format validation (basic)
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        contactResponse.innerHTML = '<p class="error">Please enter a valid email address.</p>';
        return;
      }

      //  Submit the form data via Fetch API or simulate response
      const action = (contactForm.getAttribute('action') || '').trim();

      contactResponse.innerHTML = '<p>Sending…</p>';

      const data = new FormData(contactForm);

      if (action && action !== '#' && !action.startsWith(window.location.origin)) {
        // Real submit via fetch
        fetch(action, {
          method: 'POST',
          body: data,
          headers: { 'Accept': 'application/json' }
        }).then(response => {
          if (response.ok) {
            contactResponse.innerHTML = '<p class="success">Thank you — your message has been sent.</p>';
            contactForm.reset();
          } else {
            return response.json().then(err => {
              contactResponse.innerHTML = '<p class="error">Sorry, there was a problem sending your message.</p>';
            });
          }
        }).catch(() => {
          contactResponse.innerHTML = '<p class="error">Network error. Please try again later.</p>';
        });
      } else {
        // simulate success (for local testing / assessment)
        setTimeout(() => {
          contactResponse.innerHTML = `<p class="success">Thank you, ${name}. Your message has been received (local demo).</p>`;
          contactForm.reset();
        }, 600);
      }
    });
  }
//(W3Schools. n.d.)
  /* ---------- NEWSLETTER / SUBSCRIBE (prevent normal submit & show response) ---------- */
  const subscribeForm = document.getElementById('subscribeForm');
  const subscribeResponse = document.getElementById('subscribe-response');

  if (subscribeForm) {
    subscribeForm.addEventListener('submit', function (e) {
      e.preventDefault(); // stop normal navigation / page reload

      const emailInput = document.getElementById('subscribeEmail');
      const email = (emailInput && emailInput.value || '').trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!email) {
        subscribeResponse.innerHTML = '<p class="error">Please enter your email address.</p>';
        return;
      }
      if (!emailPattern.test(email)) {
        subscribeResponse.innerHTML = '<p class="error">Please enter a valid email address.</p>';
        return;
      }

      subscribeResponse.innerHTML = '<p>Subscribing…</p>';

      const action = (subscribeForm.getAttribute('action') || '').trim();
      const formData = new FormData(subscribeForm);

      // If action is a real endpoint, POST to it, otherwise simulate response
      if (action && action !== '#' && !action.startsWith(window.location.origin)) {
        fetch(action, { method: 'POST', body: formData, headers: { 'Accept': 'application/json' } })
          .then(res => {
            if (res.ok) {
              subscribeResponse.innerHTML = '<p class="success">Subscribed — check your email to confirm.</p>';
              subscribeForm.reset();
            } else {
              subscribeResponse.innerHTML = '<p class="error">Subscription failed. Try again later.</p>';
            }
          })
          .catch(() => {
            subscribeResponse.innerHTML = '<p class="error">Network error. Please try again later.</p>';
          });
      } else {
        // local demo response (prevents navigation)
        setTimeout(() => {
          subscribeResponse.innerHTML = `<p class="success">Thanks — ${email} has been added (demo).</p>`;
          subscribeForm.reset();
        }, 500);
      }
    });
  }
//(W3Schools. n.d.)
  /* ---------- SEARCH FUNCTIONALITY ---------- */
  const searchForm = document.querySelector('form.site-search') || document.getElementById('searchForm');
  const searchInput = document.getElementById('searchInput');

  function normalize(s){ return (s||'').toLowerCase().trim(); }

  function getSearchableItems() {
    return Array.from(document.querySelectorAll('[id$="-images"] > div, .product-item'));
  }

  function runFilter(query) {
    const q = normalize(query);
    getSearchableItems().forEach(item => {
      const nameAttr = normalize(item.dataset && item.dataset.name);
      const label = nameAttr || normalize(item.querySelector('span')?.textContent) || normalize(item.textContent);
      item.style.display = (q === '' || label.includes(q)) ? '' : 'none';
    });
  }

  // On products.html, prefill and filter if ?q=... is present
  if (location.pathname.endsWith('products.html')) {
    const params = new URLSearchParams(location.search);
    const q = params.get('q') || '';
    if (searchInput) searchInput.value = q;
    if (q) runFilter(q);

    if (searchInput) {
      searchInput.addEventListener('input', (e) => runFilter(e.target.value));
    }
  }

  // On any page, handle submit
  if (searchForm && searchInput) {
    searchForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const q = (searchInput.value || '').trim();
      // Always redirect to products.html?q=searchterm 
      if (!location.pathname.endsWith('products.html')) {
        window.location.href = 'products.html' + (q ? ('?q=' + encodeURIComponent(q)) : '');
      } else {
        // On products.html, run filter 
        runFilter(q);
        const url = new URL(location.href);
        if (q) url.searchParams.set('q', q); else url.searchParams.delete('q');
        history.replaceState(null, '', url);
      }
    });
  }//(W3Schools. n.d.)
});
